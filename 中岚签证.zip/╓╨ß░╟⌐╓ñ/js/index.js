$(function(){
        $(window).scroll(function(){
            //具体数据

            //具体数据结束
        });
        //侧边导航栏
        //第一个
       $("#navfixed").find("li").eq(0).hover(function(){
           $(".nav1").stop().fadeToggle(500);//淡入淡出效果
       });
        //第二个
        $("#navfixed").find("li").eq(1).hover(function(){
            $(".nav2").stop().slideToggle(500);//拉帘效果
        });
        //第三个
        $("#navfixed").find("li").eq(2).hover(function(){
            $(".nav3").stop().toggle(500);//拉帘效果
        });
        $(window).scroll(function(){
            if($(this).scrollTop()>230){
                $("#navfixed").find("li").eq(4).show(500);
            }else{
                $("#navfixed").find("li").eq(4).hide(500);
            }
        });
        $("#navfixed").find("li").eq(4).on("click",function(){
            $('html,body').animate({
                scrollTop: 0
            },1000);
        })

        //具体数据
        $(window).scroll(function(){
            var span1=$("#performance .num").eq(0).find("span");
            var span2=$("#performance .num").eq(1).find("span");
            var span3=$("#performance .num").eq(2).find("span");
            var span4=$("#performance .num").eq(3).find("span");
            var timer1=null;
            var n1 = 0;
            var timer2=null;
            var n2 = 0;
            var timer3=null;
            var n3 = 0;
            var timer4=null;
            var n4 = 0;
            if($("html,body").scrollTop()<270){
                span1.text(0);
                span2.text(0);
                span3.text(0);
                span4.text(0);
            }else{
                $(window).off("scroll");
                timer1=setInterval(function(){
                    if(n1>18397){
                        clearInterval(timer1);
                        span1.text(18+","+397);
                        n1=0;
                    }else{
                        if(n1>999){
                            var a = parseInt(n1/1000)+"";
                            var b =parseInt(n1%1000)+"";
                            span1.text(a+","+b);
                        }else{
                            span1.text(n1);
                        }
                    }
                    n1+=50;
                },1);
                timer2=setInterval(function(){
                    if(n2>98){
                        clearInterval(timer2);
                        span2.text(98.9);
                        n2=0;
                    }else{
                        if(n2>999){
                            var a = parseInt(n2/1000)+"";
                            var b =parseInt(n2%1000)+"";
                            span2.text(a+","+b);
                        }else{
                            span2.text(n2);
                        }
                    }
                    n2+=2;
                },30);
                timer3=setInterval(function(){
                    if(n3>3273){
                        clearInterval(timer3);
                        span3.text(3+","+273);
                        n3=0;
                    }else{
                        if(n3>999){
                            var a = parseInt(n3/1000)+"";
                            var b =parseInt(n3%1000)+"";
                            span3.text(a+","+b);
                        }else{
                            span3.text(n3);
                        }
                    }
                    n3+=60;
                },30);
                timer4=setInterval(function(){
                    $(window).off("scroll");
                    if(n4>100){
                        clearInterval(timer4);
                        span4.text(100);
                        n4=0;
                    }else{
                        span4.text(n4);
                    }
                    n4+=2;
                },30);
            }
        })
})